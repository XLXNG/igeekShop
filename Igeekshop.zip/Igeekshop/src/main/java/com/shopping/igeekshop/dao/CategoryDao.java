package com.shopping.igeekshop.dao;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Category;

import java.util.List;

/**
 * @author xlXiang
 */
public interface CategoryDao {

    /**
     * 删除类别
     * @param cid
     */
    void deleteCategoryByCid(@Param("cid")Integer cid);

    /**
     * 添加分类
     * @param category
     */
    void addCategory(@Param("category") Category category);

    /**
     * 更改分类
     * @param category                 
     */
    void upCategoryByCid(@Param("category")Category category);

    /**
     * 查询类别
     * @param cid
     */
    Category queryCategoryByCid(@Param("cid")Integer cid);

    /**
     * 查询所有fenl
     * @return
     */
    List<Category> queryAllCategory();
}
