package com.shopping.igeekshop.dao;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Product;

import java.util.List;
import java.util.Set;

/**
 * @author xlXiang
 */
public interface ProductDao {

    /**
     * 查询热门商品
     * @return
     */
    List<Product> queryHotProduct();

    /**
     * 获取最新商品
     * @return
     */
    List<Product> queryLatestProduct();

    /**
     * 获取商品列表-类别
     * @param categoryName
     * @param begin
     * @return
     */
    List<Product> queryProductByCategory(@Param("categoryName")String categoryName,@Param("begin") int begin);

    /**
     * 获取商品列表-名称
     * @param pname
     * @param begin
     * @return
     */
    List<Product> queryProductByPname(@Param("pname")String pname,@Param("begin") int begin);

    /**
     * 获取商品总数-类别
     * @param categoryName
     * @return
     */
    int queryProductCountByCategory(@Param("categoryName")String categoryName);

    /**
     * 获取商品总数-名称
     * @param pname
     * @return
     */
    int queryProductCountByPname(@Param("pname")String pname);

    /**
     * 获取商品信息
     * @param pid
     * @return
     */
    Product queryProductInfoByPid(@Param("pid")String pid);

    /**
     * 查询浏览记录对应的商品信息
     * @param pids
     * @return
     */
    List<Product> queryProductInfoByPids(@Param("pids") Set<String> pids);

    /**
     * 获取所有商品信息
     * @return
     */
    List<Product> queryAllProductInfo();

    /**
     * 添加商品
     * @param product
     */
    void addProduct(@Param("product")Product product);

    /**
     * 删除商品
     * @param pid
     */
    void deleteProductByPid(@Param("pid")Integer pid);

    /**
     * 修改商品信息
     * @param product
     */
    void upProductInfo(@Param("product")Product product);

}
