package com.shopping.igeekshop.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;
import com.shopping.igeekshop.Util.UploadFileUtil;
import com.shopping.igeekshop.entity.Product;
import com.shopping.igeekshop.service.ProductService;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@Controller
public class ProductController {
    @Autowired
    private ProductService productService;

    /**
     * 商品列表页面
     * @author zl
     * @return
     */
    @RequestMapping(value = "/admin/product/list")
    public ModelAndView adminProductList() {
        ModelAndView mav = new ModelAndView("admin/product/list");
        List<Product> productList = productService.getAllProductInfo();
        mav.addObject("productList", productList);
        return mav;
    }


    /**
     * 删除商品
     * @author zl
     * @param pid 商品ID
     * @return
     */
    @RequestMapping("admin/deleteProduct")
    public String deleteProductByPid(Integer pid){
        //删除商品
        productService.deleteProductByPid(pid);
        return "redirect:/admin/product/list";
    }

    /**
     * 添加商品
     * @author zl
     * @param request
     * @param product
     * @return
     * @throws IOException
     */
    @RequestMapping("/admin/addProduct")
    public String addProduct(HttpServletRequest request, Product product) throws IOException {
        //对上传的图片进行处理
        CommonsMultipartFile productImg = null;
        CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        //判断上传图片是否为空
        if (commonsMultipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            //从Request中取出文件流
            productImg = (CommonsMultipartFile) multipartHttpServletRequest.getFile("productImg");
            //上传图片后，返回的图片名
            String imgAdd = UploadFileUtil.uploadFile(productImg.getInputStream(),productImg.getOriginalFilename());
            //将文件名添加到商品信息中
            product.setPimage(imgAdd);
        }
        product.setPdate(new Date());
        //添加商品到数据库
        productService.addProduct(product);
        return "redirect:/admin/product/list";
    }

    /**
     * 修改商品信息
     * @author zl
     * @param request
     * @param product
     * @return
     * @throws IOException
     */
    @RequestMapping("/upProductInfo")
    public String upProductInfo(HttpServletRequest request, Product product) throws IOException {
        //对上传的图片进行处理
        CommonsMultipartFile productImg = null;
        CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        //判断上传图片是否为空
        if (commonsMultipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            //从Request中取出文件流
            productImg = (CommonsMultipartFile) multipartHttpServletRequest.getFile("productImg");
            if(product!=null){
                //上传图片后，返回的图片名
                String imgAdd = UploadFileUtil.uploadFile(productImg.getInputStream(),productImg.getOriginalFilename());
                //将文件名添加到商品信息中
                product.setPimage(imgAdd);
            }
        }
        //修改商品信息到数据库
        productService.upProductInfo(product);
        //跳转回页面
        return "redirect:/admin/product/list";
    }
}
