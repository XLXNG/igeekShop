package com.shopping.igeekshop.service;

import com.sun.org.apache.xpath.internal.operations.Bool;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.User;

/**
 * @author xlXiang
 */
public interface UserService {
    /**
     * 用户注册
     * @param user
     */
    void userRegister(User user);

    /**
     * 用户登录
     *
     * @param loginInfo
     * @return
     */
    LoginInfo userLogin(LoginInfo loginInfo);

    /**
     * 管理员登录
     * @param loginInfo
     * @return
     */
    Boolean adminInfo(LoginInfo loginInfo);

    /**
     * 账户激活
     * @param uid
     * @param code
     */
    void userActive(Integer uid,String code);

    /**
     * Description 邮箱或者用户名是否注册过
     * @author xxl
     * @date 2019/8/1 11:22
     * @param user
     * @return java.lang.Boolean
    */
    Boolean existEmailOrName(User user);

    /**
     * 获取用户信息
     * @param uid
     * @return
     */
    User userInfo(int uid);
    /**
     * 根据用户名，判断用户名是否存在
     * @param userName
     * @return
     */
    Integer queryUserNameCount(String userName);
}
