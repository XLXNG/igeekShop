package com.shopping.igeekshop.Util;

import com.google.code.kaptcha.Constants;

import javax.servlet.http.HttpServletRequest;

/**
 * @author xlXiang
 */
public class CodeUtil {

    /**
     * 对验证码进行验证
     * @param request
     * @return
     */
    public static boolean checkVerifyCode(HttpServletRequest request){
        //服务器生成的验证码
        String verifyCodeExpected=(String)request.getSession().getAttribute(Constants.KAPTCHA_SESSION_KEY);
        //获取客户端输入的验证码
        String verifyCodeActual = request.getParameter("verifyCodeActual");
        //比较
        if (verifyCodeActual==null||!verifyCodeActual.equalsIgnoreCase(verifyCodeExpected)){
            return false;
        }
        return true;
    }
}
