package com.shopping.igeekshop.entity;

import lombok.Data;


/**
 * @author xlXiang
 */
@Data
public class User {
    /**
     * 用户Id
     * 用户名
     * 密码
     * 姓名
     * 邮箱
     * 性别
     * 生日
     * 电话
     * 激活码
     * 用户状态
     */
    private Integer uid;
    private String username;
    private String password;
    private String name;
    private String email;
    private String telephone;
    private String birthday;
    private String sex;
    private  Integer state;
    private String code;
    private Integer vip;
}
