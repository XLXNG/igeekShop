package com.shopping.igeekshop.service;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Category;

import java.util.List;

/**
 * @author xlXiang
 */
public interface CategoryService {

    /**
     * 删除类别
     * @param cid
     */
    void deleteCategoryByCid(Integer cid);

    /**
     * 添加分类
     * @param category
     */
    void addCategory(Category category);

    /**
     * 更改分类
     * @param category
     */
    void upCategoryByCid(Category category);

    /**
     * 查询类别
     * @param cid
     */
    Category queryCategoryByCid(Integer cid);

    /**
     * 获取所有分类
     * @return
     */
    List<Category> queryAllCategory();
}
