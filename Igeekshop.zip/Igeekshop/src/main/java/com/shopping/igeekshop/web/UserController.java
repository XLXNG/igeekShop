package com.shopping.igeekshop.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.shopping.igeekshop.Util.CodeUtil;
import com.shopping.igeekshop.Util.MD5Util;
import com.shopping.igeekshop.Util.MailUtils;
import com.shopping.igeekshop.Util.RandomUtils;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.User;
import com.shopping.igeekshop.service.UserService;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;


/**
 * @author xlXiang
 */
@Controller
public class UserController {

    @Autowired
    UserService userService;

    /**
     * 用户注册
     *
     * @param user
     * @return
     */
    @RequestMapping(value = "/userRegister", method = {RequestMethod.POST})
    public ModelAndView userRegister(HttpServletRequest request, User user) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        ModelAndView mav = new ModelAndView();
        //对客户端的验证码进行验证
        System.out.println(user);
        if (!CodeUtil.checkVerifyCode(request)) {
            //如果验证错误这跳转回注册页面,且显示验证码错误信息
            mav.setViewName("/register");
            mav.addObject("errMsg", "验证码错误");
            return mav;
        }
        if(userService.existEmailOrName(user)){
            mav.setViewName("/register");
            mav.addObject("errMsg", "邮箱已注册");
            return mav;
        }

//        String encryption= MD5Util.EncoderByMd5(user.getPassword());
        String emailCheckCode = request.getParameter("emailCheckCode").toLowerCase();
        if (null == emailCheckCode && (!emailCheckCode.equals(request.getSession().getAttribute("emailCheckCode").toString()))) {
            //如果邮箱验证码错误这跳转回注册页面,且显示验证码错误信息
            mav.setViewName("/register");
            mav.addObject("errMsg", "邮箱验证码错误");
            return mav;
        } else {
            //对用户输入的密码进行MD5加密
            String encryption = MD5Util.EncoderByMd5(user.getPassword());
            //将密码换为加密后的密码
            user.setPassword(encryption);
            //设置用户激活码
            user.setCode(encryption);
            //设置用户初始状态 0为未激活，1为已激活
            user.setState(1);
            //用户注册
            userService.userRegister(user);
            //设置性别
            if (request.getParameter("sex").equals("1")) {
                user.setSex("男");
            } else {
                user.setSex("女");
            }
            //跳转的页面
            mav.setViewName("redirect:/index");
            return mav;
        }
    }

    /**
     * 用户登录
     *
     * @param request
     * @param loginInfo 客户端输入的登录信息
     * @return
     */
    @RequestMapping(value = "/userLogin", method = RequestMethod.POST)
    public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response, LoginInfo loginInfo, String autologin, String autoUserName) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        ModelAndView mav = new ModelAndView();
        //对用户输入的验证码进行验证
        if (!CodeUtil.checkVerifyCode(request)) {
            //验证码输入错误跳转回登录页面,且显示验证码错误信息
            mav.setViewName("login");
            mav.addObject("errMsg", "输入了错误的验证码");
            return mav;
        }
        //判断输入的用户名及密码是否为空
        if (loginInfo != null && loginInfo.getUsername() != null && loginInfo.getPassword() != null) {
            //数据库返回的用户信息
            LoginInfo userInfo = userService.userLogin(loginInfo);
            //对返回的用户信息进行验证
            if (MD5Util.checkpassword(loginInfo.getPassword(), userInfo.getPassword())) {
                //验证成功
                //将用户信息存储到Session中，为自动登录做准备，首页用户名
                HttpSession session = request.getSession();
                userInfo.setPassword(MD5Util.EncoderByMd5(userInfo.getPassword()));
                session.setAttribute("userInfo", userInfo);
                //用户选择记住用户名时
                if ("true".equals(autoUserName) || "true".equals(autologin)) {
                    //将用户名存储到Cookie中
                    Cookie username = new Cookie("username", loginInfo.getUsername());
                    //设置Cookie有效时间
                    username.setMaxAge(60 * 60);
                    //将Cookie放到根目录下，使得其他同源页面能够读取
                    username.setPath("/");
                    //响应给客户端
                    response.addCookie(username);
                }
                //用户选择自动登录时
                if ("true".equals(autologin)) {
                    //将密码存储到Cookie中
                    Cookie password = new Cookie("password", MD5Util.EncoderByMd5(loginInfo.getPassword()));
                    //设置Cookie有效时间
                    password.setMaxAge(60 * 60);
                    //将Cookie放到根目录下，使得其他同源页面能够读取
                    password.setPath("/");
                    //响应给客户端
                    response.addCookie(password);
                }
                //返回用户信息给JSP页面,用来显示首页顶部的用户名信息
                mav.addObject("userInfo", loginInfo);
                //跳转到首页
                mav.setViewName("redirect:/index");
                //设置是否登录，用于服务端检测（服务器重启后）
//                Cookie jsessionid = new Cookie("JSESSIONID", MD5Util.EncoderByMd5(userInfo.getPassword()));
//                jsessionid.setMaxAge(60 * 60);
//                jsessionid.setPath("/");
//                response.addCookie(jsessionid);

                session.setAttribute("isLogin", "1");
                return mav;
            }
        }
        //验证失败,则跳转会登录页面,并显示账户名或密码错误
        mav.setViewName("login");
        mav.addObject("errMsg", "账户名或密码错误");
        return mav;
    }


    /**
     * 登录管理页面
     *
     * @param request
     * @param response
     * @param loginInfo 登录信息
     * @return
     */
    @RequestMapping(value = "/adminLogin", method = RequestMethod.POST)
    public String adminLogin(HttpServletRequest request, HttpServletResponse response, LoginInfo loginInfo) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        if (loginInfo != null && loginInfo.getUsername() != null && loginInfo.getPassword() != null) {
            //数据库返回的用户信息
            LoginInfo userInfo = userService.userLogin(loginInfo);
            if (userInfo!=null&&MD5Util.checkpassword(loginInfo.getPassword(), userInfo.getPassword())) {
                //将登录信息存储到Session中
                HttpSession session = request.getSession();
                session.setAttribute("adminInfo", loginInfo);
                return "redirect:/admin/home";
            }
        }
        return "/admin/index";
    }

    /**
     * 注销登录
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        //从Session中删除用户的登录信息
        HttpSession session = request.getSession();
        session.invalidate();
        //清除了Cookie
        Cookie username = new Cookie("username", null);
        Cookie password = new Cookie("password", null);
        username.setMaxAge(0);
        password.setMaxAge(0);
        response.addCookie(username);
        response.addCookie(password);
        //跳转回首页
        return "redirect:/index";
    }

    /**
     * 用户激活（启用，转为邮箱验证码验证）
     *
     * @param uid  用户ID
     * @param code 激活码
     * @return
     */
    @RequestMapping(value = "/userActive")
    public String userActive(Integer uid, String code) {
        userService.userActive(uid, code);
        //跳转回登录页面
        return "redirect:login";
    }

    /**
     * 发送验证码邮件
     *
     * @param request
     * @return
     */
    @RequestMapping(value = "/sendEmailCheckCode")
    public @ResponseBody
    String sendMailCode(HttpServletRequest request) {
        String emailCode = RandomUtils.randomNumber(6);
        request.getSession().setAttribute("emailCheckCode", emailCode);
        request.getSession().setMaxInactiveInterval(20 * 60);
        //发送邮件
//        String url = "http://localhost:8080/userActive?uid="+user.getUid()+"&code="+encryption;
        String str = "这封信是由 IgeekShop 发送的。\n" +
                "您收到这封邮件，是由于在 IgeekShop 获取了验证码。如果您并没有访问过 IgeekShop ，或没有进行上述操作，请忽略这封邮件。您不需要退订或进行其他进一步的操作。\n" +
                "<br>" +
                "----------------------------------------------------------------------<br>" +
                "亲爱的客户，您当前的验证码为 <h2 style='color:red'>" + emailCode + "</h2>该验证码20分钟内验证有效，请及时验证<br>" +
                "----------------------------------------------------------------------";
        MailUtils.sendMail(request.getParameter("emailCheckCode"), str);

        System.out.println(request.getParameter("emailCheckCode"));
        //跳转回登录页面

        return "{\"status\":1}";
    }

    /**
     * 判断邮箱是否已经注册
     *
     * @param request
     * @return
     */
    @RequestMapping("/existEmailOrName")
    @ResponseBody
    public Map<String,Boolean> existEmail(HttpServletRequest request) {
        User user=new User();
        user.setEmail(request.getParameter("email"));
        user.setUsername(request.getParameter("username"));
        Boolean flag = userService.existEmailOrName(user);
        Map<String,Boolean> m=new HashMap<String, Boolean>();
        if (flag) {
            m.put("success",true);
        }else {
            m.put("success",false);
        }
        return m;
    }

    /**
     * 返回用户信息
     * @param request
     * @return
     */
    @RequestMapping("/userinfo")
    public ModelAndView userInfo(HttpServletRequest request){
        ModelAndView mav=new ModelAndView();
        HttpSession session = request.getSession();
        LoginInfo loginInfo = (LoginInfo) session.getAttribute("userInfo");
        User user = userService.userInfo(loginInfo.getUid());
        mav.addObject("userIn",user);
        mav.setViewName("userinform");
        return mav;
    }
}
