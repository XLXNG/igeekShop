package com.shopping.igeekshop.dao;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.User;

/**
 * @author xlXiang
 */
public interface UserDao {
    /**
     * 用户注册
     * @param user
     */
    void userRegister(@Param("user")User user);

    /**
     * 用户登录
     * @param loginInfo
     */
    LoginInfo userLogin(@Param("loginInfo")LoginInfo loginInfo);

    /**
     * 管理员登录
     * @param loginInfo
     */
    LoginInfo adminLogin(@Param("loginInfo")LoginInfo loginInfo);

    /**
     * 账户激活
     * @param uid
     * @param code
     */
    void userActive(@Param("uid")Integer uid,@Param("code")String code);

    /**
     * 判断邮箱是否已经注册过
     * @param user
     * @return
     */
    Integer existEmailOrName(User user);

    /**
     * 获取用户信息
     * @return
     */
    User userInfo(int uid);
    /**
     * 根据用户名，判断用户名是否存在
     * @param userName
     * @return
     */
    Integer queryUserNameCount(@Param("userName")String userName);
}
