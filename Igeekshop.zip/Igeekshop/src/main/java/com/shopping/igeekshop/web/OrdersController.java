package com.shopping.igeekshop.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Orders;
import com.shopping.igeekshop.service.OrderitemService;
import com.shopping.igeekshop.service.OrdersService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

/**
 * @author xlXiang
 */
@Controller
public class OrdersController {

    @Autowired
    private OrdersService ordersService;
    @Autowired
    private OrderitemService orderitemService;
    /**
     * 提交订单
     * @param request
     * @return
     */
    @RequestMapping(value = "/submitOrders")
    public String submitOrders(HttpServletRequest request,Orders orders){
        //获取登录信息
        HttpSession session = request.getSession();
        LoginInfo userInfo = (LoginInfo) session.getAttribute("userInfo");
        if (userInfo == null) {
            //未登录，则跳转回登录页面
            return "redirect:/login";
        }
        //向订单中写入生成时间
        orders.setOrdertime(new Date());
        //获取购物车中的商品信息
        List<Orderitem> orderitemList = orderitemService.getOrderitemByUid(userInfo.getUid());
        //计算小计
        Double sum=0.0;
        for (Orderitem orderitem:orderitemList
        ) {
            sum+=orderitem.getSubtotal();
        }
        //写入小计，订单状态等信息
        orders.setTotal(sum);
        orders.setState(1);
        orders.setUid(userInfo.getUid());
        //提交订单
        ordersService.submitOrders(orders);
        //清空购物车
        orderitemService.delectOrderitemAll(userInfo.getUid());
        //跳转到订单列表
        return "redirect:/order_list";
    }

/**
 * Description 查询订单信息 返回json
 * @author zl
 * @date 2019/8/1 22:35
 * @param oid
 * @param request
 * @return java.util.List<com.shopping.igeekshop.entity.Orderitem>
*/
    @RequestMapping("/admin/orderInfo")
    public @ResponseBody List<Orderitem> orderInfo(String oid, HttpServletRequest request){
        return ordersService.queryOrderByOid(Integer.valueOf(oid));
    }
}
