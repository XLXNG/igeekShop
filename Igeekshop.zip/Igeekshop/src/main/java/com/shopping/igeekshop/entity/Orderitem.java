package com.shopping.igeekshop.entity;

import lombok.Data;

/**
 * @author xlXiang
 */
@Data
public class Orderitem {
    /**
     * id
     * 数量
     * 小计
     * 商品Id
     * 订单Id
     */
    private Integer itemId;
    private Integer count;
    private Double subtotal;
    private Product product;
    private Integer oid;
    private Integer uid;
}
