package com.shopping.igeekshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.igeekshop.dao.CategoryDao;
import com.shopping.igeekshop.entity.Category;
import com.shopping.igeekshop.service.CategoryService;

import java.util.List;

/**
 * @author xlXiang
 */
@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    CategoryDao categoryDao;

    /**
     * 删除类别
     *
     * @param cid
     */
    @Override
    public void deleteCategoryByCid(Integer cid) {
        categoryDao.deleteCategoryByCid(cid);
    }

    /**
     * 添加分类
     *
     * @param category
     */
    @Override
    public void addCategory(Category category) {
        categoryDao.addCategory(category);
    }

    /**
     * 更改分类
     *
     * @param category
     */
    @Override
    public void upCategoryByCid(Category category) {
        categoryDao.upCategoryByCid(category);
    }

    /**
     * 查询类别
     *
     * @param cid
     */
    @Override
    public Category queryCategoryByCid(Integer cid) {
        return categoryDao.queryCategoryByCid(cid);
    }

    /**
     * 获取所有分类
     *
     * @return
     */
    @Override
    public List<Category> queryAllCategory() {
        return categoryDao.queryAllCategory();
    }
}
