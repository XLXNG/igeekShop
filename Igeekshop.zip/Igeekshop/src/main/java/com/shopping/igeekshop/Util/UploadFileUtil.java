package com.shopping.igeekshop.Util;

import com.google.gson.Gson;
import com.qiniu.common.QiniuException;
import com.qiniu.common.Zone;
import com.qiniu.http.Response;
import com.qiniu.storage.Configuration;
import com.qiniu.storage.UploadManager;
import com.qiniu.storage.model.DefaultPutRet;
import com.qiniu.util.Auth;

import java.io.InputStream;

/**
 * @author xlXiang
 */
public class UploadFileUtil {

    public static String uploadFile(InputStream productImg,String fileName){
        //构造一个带指定Zone对象的配置类
        Configuration cfg = new Configuration(Zone.zone2());
        UploadManager uploadManager = new UploadManager(cfg);
        //生成上传凭证
        //简单上传的凭证
        String accessKey = "E07ipcYc6VM9TEfwvGMZ9xDJ6TTLFsqVrVJlh-cm";
        String secretKey = "N6_BO5IXAQWYt70j-dxjz_9Kq96IE1-LgUMrE833";
        //bucket名
        String bucket = "blog";
        //如果是Windows情况下，格式是 D:\\qiniu\\test.png
        String localFilePath = "C:\\Users\\xlXiang\\Desktop\\头像.jpg";
        //默认不指定key的情况下，以文件内容的hash值作为文件名
        String key = null;
        Auth auth = Auth.create(accessKey, secretKey);
        String upToken = auth.uploadToken(bucket);
        try {
            //文件上传
            Response response = uploadManager.put(productImg, key, upToken,null,null);
            //解析上传成功的结果
            DefaultPutRet putRet = new Gson().fromJson(response.bodyString(), DefaultPutRet.class);
            //返回文件名
            return "http://192.168.10.1:8008/"+putRet.key;
        } catch (QiniuException ex) {
            Response r = ex.response;
            System.err.println(r.toString());
            try {
                System.err.println(r.bodyString());
            } catch (QiniuException ex2) {
                //ignore
            }
        }
        return null;
    }
}
