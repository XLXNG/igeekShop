package com.shopping.igeekshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.igeekshop.dao.OrderitemDao;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.service.OrderitemService;

import java.util.List;

/**
 * @author xlXiang
 */
@Service
public class OrderitemServiceImpl implements OrderitemService {

    @Autowired
    OrderitemDao orderitemDao;

    /**
     * 添加商品到购物车
     * @param uid
     * @param orderitem
     */
    @Override
    public void addToOrderitem(Integer uid,Orderitem orderitem) {
        //查询购物车中是否已经存在该商品
        Integer itemId = orderitemDao.queryOrderitemIdByPid(uid,orderitem.getProduct().getPid());
        if(itemId!=null&&itemId>0){
            //修改购物车中该商品数量
            orderitem.setItemId(itemId);
            orderitemDao.upOrderitem(orderitem);
        }else{
            //添加商品到购物车
            orderitemDao.addToOrderitem(orderitem);
        }
    }

    /**
     * 修改购物车中商品的数量
     *
     * @param orderitem
     */
    @Override
    public void upOrderitem(Orderitem orderitem) {
        orderitemDao.upOrderitem(orderitem);
    }

    /**
     * 查询购物车中是否已经存在该商品
     *
     * @param uid
     * @param pid
     * @return
     */
    @Override
    public Integer queryOrderitemIdByPid(Integer uid, Integer pid) {
        return orderitemDao.queryOrderitemIdByPid(uid,pid);
    }

    /**
     * 获取购物车中所有的商品信息
     *
     * @param uid
     * @return
     */
    @Override
    public List<Orderitem> getOrderitemByUid(Integer uid) {
        return orderitemDao.queryOrderitemByUid(uid);
    }

    /**
     * 删除购物车中的商品-pid
     *
     * @param pid
     * @param uid
     */
    @Override
    public void delectOrderitemByPid(Integer uid,Integer pid) {
        orderitemDao.delectOrderitemByPid(uid,pid);
    }

    /**
     * 清空购物车
     *
     * @param uid
     */
    @Override
    public void delectOrderitemAll(Integer uid) {
        orderitemDao.delectOrderitemAll(uid);
    }

    /**
     * 绑定订单与商品的信息
     *
     * @param uid
     * @param oid
     */
    @Override
    public void setOrdersId(Integer uid, Integer oid) {
        orderitemDao.setOrdersId(uid,oid);
    }
}
