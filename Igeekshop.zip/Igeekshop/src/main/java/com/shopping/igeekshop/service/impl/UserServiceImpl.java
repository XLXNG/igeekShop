package com.shopping.igeekshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.igeekshop.Util.MD5Util;
import com.shopping.igeekshop.dao.UserDao;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.User;
import com.shopping.igeekshop.service.UserService;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

/**
 * @author xlXiang
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserDao userDao;

    /**
     * 用户注册
     *
     * @param user
     */
    @Override
    public void userRegister(User user) {
        System.out.println(user);
        userDao.userRegister(user);
    }

    /**
     * 用户登录
     *
     * @param loginInfo
     * @return
     */
    @Override
    public LoginInfo userLogin(LoginInfo loginInfo) {
        return userDao.userLogin(loginInfo);
    }

    /**
     * 管理员登录
     *
     * @param loginInfo
     * @return
     */
    @Override
    public Boolean adminInfo(LoginInfo loginInfo) {
        LoginInfo userInfo = userDao.adminLogin(loginInfo);
        if(userInfo!=null){
            loginInfo.setUid(userInfo.getUid());
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    /**
     * 账户激活
     * @param uid
     * @param code
     */
    @Override
    public void userActive(Integer uid, String code) {
        userDao.userActive(uid,code);
    }

    /**
     * Description youxiangandname
     * @author xxl
     * @date 2019/8/1 22:46
     * @param user
     * @return java.lang.Boolean
    */
    @Override
    public Boolean existEmailOrName(User user) {
        if(userDao.existEmailOrName(user)==1){
            return Boolean.TRUE;
        }else
        {
            return Boolean.FALSE;
        }
    }

    /**
     * 获取用户信息
     * @param uid
     * @return
     */
    @Override
    public User userInfo(int uid) {
        return userDao.userInfo(uid);
    }
    /**
     * 根据用户名，判断用户名是否存在
     *
     * @param userName
     * @return
     */
    @Override
    public Integer queryUserNameCount(String userName) {
        return userDao.queryUserNameCount(userName);
    }

}
