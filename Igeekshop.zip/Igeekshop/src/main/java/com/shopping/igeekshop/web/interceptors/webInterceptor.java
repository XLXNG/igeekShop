package com.shopping.igeekshop.web.interceptors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.User;
import com.shopping.igeekshop.service.CategoryService;
import com.shopping.igeekshop.service.UserService;

import javax.mail.Session;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 拦截器==>过滤器
 * author xxl
 * create 2019-07-29-14:51
 */
public class webInterceptor implements HandlerInterceptor {
    @Autowired
    private UserService userService;

    @Autowired
    private CategoryService categoryService;

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        //取商品类别，渲染到页面导航栏
        httpServletRequest.setAttribute("categoryList",categoryService.queryAllCategory());
        //        //取出客服端的cookie中的账号密码
        Cookie[] cookies = httpServletRequest.getCookies();
        String username = null;
        String password = null;
        //遍历cookie，获取用户名和密码
        if(cookies!=null)
            for( Cookie cookie : cookies) {
                if (cookie.getName()!=null && "username".equals(cookie.getName())) {
                    username = cookie.getValue();
                }
                if (cookie.getName()!=null &&"password".equals(cookie.getName())) {
                    password = cookie.getValue();
                }
            }
        String requestURL = httpServletRequest.getRequestURI().toString();
//        数据库返回的用户数据
        if(username!=null&&password!=null&& !requestURL.contains("admin")) {
            LoginInfo loginIn = new LoginInfo();
            loginIn.setPassword(password);
            loginIn.setUsername(username);
            //在数据库中查询用户密码，用户名
            LoginInfo userInfo = userService.userLogin(loginIn);
            if (username.equals(userInfo.getUsername()) && password.equals(userInfo.getPassword())) {
                if(httpServletRequest.getSession().getAttribute("isLogin")==null) {
                    httpServletRequest.getSession().setAttribute("isLogin", 1);
                    httpServletRequest.getSession().setAttribute("userInfo", userInfo);
                    //返回状态码301,指示资源永久性移动到一个新的位置,未来的引用应该使用新URI及其请求。
                    httpServletResponse.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
                    //重定向URI
                    httpServletResponse.sendRedirect("/index");
                    return false;
                }else
                {
                    return true;
                }

            }
        }
        //拦截管理员，对其进行判断
        else if ((requestURL != null) && requestURL.contains("admin")){
            if(!requestURL.contains("index")&&httpServletRequest.getSession().getAttribute("adminIsLogin")==null) {
                httpServletResponse.setStatus(HttpServletResponse.SC_MOVED_PERMANENTLY);
                httpServletResponse.sendRedirect("/admin/index");
                httpServletRequest.getSession().setAttribute("adminIsLogin","1");
                return false;
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        //获取用户信息Cookie


    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
