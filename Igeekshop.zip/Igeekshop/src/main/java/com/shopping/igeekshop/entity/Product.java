package com.shopping.igeekshop.entity;

import lombok.Data;

import java.util.Date;

/**
 * @author xlXiang
 */
@Data
public class Product {
    /**
     * 商品表
     * 商品名称
     * 商品市场价
     * 商品商城价
     * 图片路径
     * 商品描述
     * 商品状态
     * 分类Id
     */
    private Integer pid;
    private String pname;
    private Double marketPrice;
    private Double shopPrice;
    private String pimage;
    private Date pdate;
    private Integer isHot;
    private String pdesc;
    private Integer pflag;
    private Integer cid;
}
