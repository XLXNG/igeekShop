package com.shopping.igeekshop.dao;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Orders;

import java.util.List;

/**
 * @author xlXiang
 */
public interface OrdersDao {

    /**
     * 提交订单
     * @param orders
     */
    void submitOrders(@Param("orders") Orders orders);

    /**
     * 查询用户所有订单
     * @param uid
     */
    List<Orders> queryAllOrders(@Param("uid")Integer uid);

    /**
     * 查询所有订单
     */
    List<Orders> queryOrders();

    /**
     * 根据oid查询订单下商品信息
     * @param oid
     * @return
     */
    List<Orderitem> queryOrderByOid(int oid);

}
