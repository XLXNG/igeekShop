package com.shopping.igeekshop.dao;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Orderitem;

import java.util.List;

/**
 * @author xlXiang
 */
public interface OrderitemDao {


    /**
     * 添加商品到购物车中
     * @param orderitem
     */
    void addToOrderitem(@Param("orderitem")Orderitem orderitem);

    /**
     * 修改购物车中商品的数量
     * @param orderitem
     */
    void upOrderitem(@Param("orderitem")Orderitem orderitem);

    /**
     * 查询购物车中是否已经存在该商品
     * @param uid
     * @param pid
     * @return
     */
    Integer queryOrderitemIdByPid(@Param("uid")Integer uid,@Param("pid")Integer pid);

    /**
     * 获取购物车中所有的商品信息
     * @param uid
     * @return
     */
    List<Orderitem> queryOrderitemByUid(@Param("uid")Integer uid);

    /**
     * 删除购物车中的商品-pid
     * @param pid
     * @param uid
     */
    void delectOrderitemByPid(@Param("uid")Integer uid,@Param("pid")Integer pid);

    /**
     * 清空购物车
     * @param uid
     */
    void delectOrderitemAll(@Param("uid")Integer uid);
    /**
     * 绑定订单与商品的信息
     * @param uid
     * @param oid
     */
    void setOrdersId(@Param("uid")Integer uid,@Param("oid")Integer oid);
}
