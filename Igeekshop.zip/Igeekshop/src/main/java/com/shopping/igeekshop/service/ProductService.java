package com.shopping.igeekshop.service;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Product;

import java.util.List;
import java.util.Set;

/**
 * @author xlXiang
 */
public interface ProductService {

    /**
     * 获取热门商品
     * @return
     */
    List<Product> getHotProduct();

    /**
     * 获取最新商品
     * @return
     */
    List<Product> getLatestProduct();

    /**
     * 获取商品列表-类别
     * @param categoryName
     * @param begin
     * @return
     */
    List<Product> getProductByCategory(String categoryName,int begin);

    /**
     * 获取商品总数-分类
     * @param categoryName
     * @return
     */
    int getProductCountByCategory(String categoryName);

    /**
     * 获取商品总数-商品名
     * @param pname
     * @return
     */
    int getProductCountByPname(String pname);
    /**
     * 获取商品列表-商品名
     * @param pname
     * @return
     */
    List<Product> getProductByPname(String pname,int begin);

    /**
     * 获取商品信息
     * @param pid
     * @return
     */
    Product getProductInfoByPid(String pid);

    /**
     * 查询浏览记录对应的商品信息
     * @param pids
     * @return
     */
    List<Product> getProductInfoByPids(Set<String> pids);

    /**
     * 获取所有商品信息
     * @return
     */
    List<Product> getAllProductInfo();

    /**
     * 删除商品
     * @param pid
     */
    void deleteProductByPid(Integer pid);

    /**
     * 修改商品信息
     * @param product
     */
    void upProductInfo(Product product);

    /**
     * 添加商品
     * @param product
     */
    void addProduct(Product product);
}
