package com.shopping.igeekshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.igeekshop.dao.OrderitemDao;
import com.shopping.igeekshop.dao.OrdersDao;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Orders;
import com.shopping.igeekshop.service.OrdersService;

import java.util.List;


/**
 * @author xlXiang
 */
@Service
public class OrdersServiceImpl implements OrdersService {

    @Autowired
    private OrdersDao ordersDao;
    @Autowired
    private OrderitemDao orderitemDao;

    /**
     * 提交订单
     *
     * @param orders
     */
    @Override
    public void submitOrders(Orders orders) {

        ordersDao.submitOrders(orders);
        orderitemDao.setOrdersId(orders.getUid(),orders.getOid());

    }

    /**
     * 获取用户所有订单
     *
     * @param uid
     */
    @Override
    public List<Orders> getAllOrders(Integer uid) {
        return ordersDao.queryAllOrders(uid);
    }

    /**
     * 查询所有订单
     */
    @Override
    public List<Orders> queryOrders() {
        return ordersDao.queryOrders();
    }

    /**
     * 查询订单下商品信息
     * @param oid
     * @return
     */
    @Override
    public List<Orderitem> queryOrderByOid(int oid) {
        return ordersDao.queryOrderByOid(oid);
    }
}
