package com.shopping.igeekshop.web;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.shopping.igeekshop.Util.ProductUtil;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.Category;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Orders;
import com.shopping.igeekshop.entity.Product;
import com.shopping.igeekshop.service.CategoryService;
import com.shopping.igeekshop.service.OrderitemService;
import com.shopping.igeekshop.service.OrdersService;
import com.shopping.igeekshop.service.ProductService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * @author xlXiang
 */
@Controller
public class PageController {

    @Autowired
    private ProductService productService;
    @Autowired
    private OrderitemService orderitemService;
    @Autowired
    private OrdersService ordersService;
    @Autowired
    private CategoryService categoryService;

    /**
     * 首页
     *
     * @return
     */
    @RequestMapping("/index")
    private ModelAndView index() {
        ModelAndView mav = new ModelAndView("index");
        List<Product> hotProductList = productService.getHotProduct();
        mav.addObject("hotProductList", hotProductList);
        List<Product> latestProductList = productService.getLatestProduct();
            mav.addObject("latestProductList", latestProductList);
            return mav;
    }

    /**
     * 首页
     *
     * @return
     */
    @RequestMapping("/")
    private ModelAndView index1() {
        ModelAndView mav = new ModelAndView("index");
        List<Product> hotProductList = productService.getHotProduct();
        mav.addObject("hotProductList", hotProductList);
        List<Product> latestProductList = productService.getHotProduct();
        mav.addObject("latestProductList", latestProductList);
        return mav;
    }

    /**
     * 登录页面
     *
     * @return
     */
    @RequestMapping("/login")
    private String loginPage(HttpServletRequest request) {
        //获取Session中的用户信息,判断用户是否登录
        HttpSession session = request.getSession();
        LoginInfo userInfo = (LoginInfo) session.getAttribute("userInfo");
        if (userInfo == null) {
            //未登录，则跳转回登录页面
            return "login";
        }
        //已登录，直接进行跳转
        return "index";
    }

    /**
     * 注册页面
     *
     * @return
     */
    @RequestMapping("/register")
    private String registerPage() {
        return "register";
    }

    /**
     * 购物车页面
     *
     * @return
     */
    @RequestMapping("/cart")
    private ModelAndView cartPage(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("cart");
        //获取Session中的用户信息,判断用户是否登录
        HttpSession session = request.getSession();
        LoginInfo userInfo = (LoginInfo) session.getAttribute("userInfo");
        if (userInfo == null) {
            mav.setViewName("redirect:/login");
            return mav;
        }
        //从数据库中取出购物车中的商品信息
        List<Orderitem> orderitemList = orderitemService.getOrderitemByUid(userInfo.getUid());
        int sum = 0;
        for (Orderitem orderitem : orderitemList
        ) {
            sum += orderitem.getSubtotal();
        }
        mav.addObject("orderitemList", orderitemList);
        mav.addObject("sum", sum);
        return mav;
    }

    /**
     * 我的订单页面
     *
     * @return
     */
    @RequestMapping("/order_list")
    private ModelAndView orderListPage(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("order_list");
        //获取Session中的用户信息,判断用户是否登录
        HttpSession session = request.getSession();
        LoginInfo userInfo = (LoginInfo) session.getAttribute("userInfo");
        if (userInfo == null) {
            mav.setViewName("redirect:/login");
            return mav;
        }

        List<Orders> ordersList = ordersService.getAllOrders(userInfo.getUid());
        mav.addObject("ordersList", ordersList);
        return mav;
    }

    /**
     * 商品信息页面
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/product_info", method = RequestMethod.GET)
    private ModelAndView productInfo(HttpServletRequest request, String pid) {
        ModelAndView mav = new ModelAndView("product_info");
        Product product = productService.getProductInfoByPid(pid);
        HttpSession session = request.getSession();
        Set<String> readHistory = (Set<String>) session.getAttribute("readHistory");
        if (readHistory == null) {
            readHistory = new HashSet<>();
        }
        readHistory.add(pid);
        session.setAttribute("readHistory", readHistory);
        mav.addObject("product", product);
        return mav;
    }

    /**
     * 商品列表页面-类别
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/product_list", method = RequestMethod.GET)
    private ModelAndView productListCname(HttpServletRequest request, String categoryName, String page) {
        ModelAndView mav = new ModelAndView("product_list");
        //获取商品
        ProductUtil.getProductByCategory(mav, productService, categoryName, page);
        HttpSession session = request.getSession();
        //获取要跳转的category，渲染到下个页面的title
        mav.addObject("currentPage",categoryName);
        //获取Session中浏览历史的商品信息
        Set<String> pids = null;
        if (session.getAttribute("readHistory") != null) {
            pids = (Set<String>) session.getAttribute("readHistory");
        }
        if (pids != null && pids.size() >= 0) {
            List<Product> readHistory = productService.getProductInfoByPids(pids);
            mav.addObject("readHistory", readHistory);
        }
        return mav;
    }

    /**
     * 商品列表页面-商品名字
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/search", method = RequestMethod.GET)
    private ModelAndView productListPname(HttpServletRequest request, String pname, String page) {
        ModelAndView mav = new ModelAndView("product_list_search");
        //获取商品
        ProductUtil.getProductByPname(mav, productService, pname, page);
        HttpSession session = request.getSession();
        //获取Session中浏览历史的商品信息
        Set<String> pids = null;
        if (session.getAttribute("readHistory") != null) {
            pids = (Set<String>) session.getAttribute("readHistory");
        }
        if (pids != null && pids.size() >= 0) {
            List<Product> readHistory = productService.getProductInfoByPids(pids);
            mav.addObject("readHistory", readHistory);
        }
        return mav;
    }

    /**
     * 订单详情页面
     *
     * @return
     */
    @RequestMapping(value = "/order_info")
    private ModelAndView orderInfo(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("order_info");
        //获取Session中的用户信息,判断用户是否登录
        HttpSession session = request.getSession();
        LoginInfo userInfo = (LoginInfo) session.getAttribute("userInfo");
        if (userInfo == null) {
            //未登录，则跳转回登录页面
            mav.setViewName("redirect:/login");
            return mav;
        }
        List<Orderitem> orderitemList = orderitemService.getOrderitemByUid(userInfo.getUid());

        int sum = 0;
        for (Orderitem orderitem : orderitemList
        ) {
            sum += orderitem.getSubtotal();
        }
        mav.addObject("orderitemList", orderitemList);
        mav.addObject("sum", sum);

        return mav;
    }

    /**
     * 管理页面的登录页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/index")
    public String adminIndex() {
        return "admin/index";
    }

    /**
     * 管理页面的主页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/home")
    public String adminHome() {
        return "admin/home";
    }

    /**
     * 管理页面的左部页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/left")
    public String adminLeft() {
        return "admin/left";
    }

    /**
     * 管理页面的底部页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/bottom")
    public String adminBottom() {
        return "admin/bottom";
    }

    /**
     * 管理页面顶部页面
     */
    @RequestMapping(value = "/admin/top")
    public ModelAndView adminTop(HttpServletRequest request) {
        ModelAndView mav = new ModelAndView("admin/top");
        HttpSession session = request.getSession();
        LoginInfo adminInfo = (LoginInfo) session.getAttribute("adminInfo");
        mav.addObject("adminName", adminInfo.getUsername());
        return mav;
    }

    /**
     * 登录管理系统欢迎页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/welcome")
    public String adminWelcome() {
        return "admin/welcome";
    }

    /**
     * 分类列表页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/category/list")
    public ModelAndView adminCategoryList() {
        ModelAndView mav = new ModelAndView("admin/category/list");
        List<Category> categoryList = categoryService.queryAllCategory();
        mav.addObject("categoryList", categoryList);
        return mav;
    }


    /**
     * 编辑分类页面
     *
     * @param cid
     * @return
     */
    @RequestMapping(value = "admin/category/edit")
    public ModelAndView adminCategoryEdit(Integer cid) {
        ModelAndView mav = new ModelAndView("admin/category/edit");
        Category category = categoryService.queryCategoryByCid(cid);
        mav.addObject("category", category);
        return mav;
    }

    /**
     * 添加分类页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/category/add")
    public String adminCwategoryAdd() {
        return "admin/category/add";
    }


    /**
     * 编辑商品页面
     *
     * @param pid
     * @return
     */
    @RequestMapping(value = "/admin/product/edit")
    public ModelAndView adminProductEdit(String pid) {
        ModelAndView mav = new ModelAndView("admin/product/edit");
        Product product = productService.getProductInfoByPid(pid);
        mav.addObject("product", product);
        return mav;
    }

    /**
     * 添加商品页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/product/add")
    public String adminProductAdd() {
        return "/admin/product/add";
    }

    /**
     * 订单列表页面
     *
     * @return
     */
    @RequestMapping(value = "/admin/order/list")
    public ModelAndView adminOrderListr() {
        ModelAndView mav = new ModelAndView("/admin/order/list");
        List<Orders> ordersList = ordersService.queryOrders();
        mav.addObject("ordersList", ordersList);
        return mav;
    }
}
