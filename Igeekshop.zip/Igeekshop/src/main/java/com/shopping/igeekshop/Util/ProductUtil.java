package com.shopping.igeekshop.Util;

import org.springframework.web.servlet.ModelAndView;
import com.shopping.igeekshop.entity.Product;
import com.shopping.igeekshop.service.ProductService;

import java.util.List;

/**
 * @author xlXiang
 */
public class ProductUtil {

    /**
     * 获取商品根据类别
     * @param mav
     * @param productService
     * @param categoryName
     * @param page
     */
    public static void getProductByCategory(ModelAndView mav, ProductService productService, String categoryName, String page){
        //当前页面号,若为空则默认为第一页
        if(page==null||page==""){
            page="1";
        }
        //商品总数
        int productCount=productService.getProductCountByCategory(categoryName);
        //可分为多少页
        int pageCount=productCount/12;
        pageCount=productCount%12==0?pageCount:pageCount+1;
        //页数
        int num = Integer.valueOf(page);
        //类别商品
        List<Product> productList = productService.getProductByCategory(categoryName,(num-1)*12);
        //总页面数
        mav.addObject("pageCount",pageCount);
        //类别名
        mav.addObject("categoryName",categoryName);
        //当前页面号
        mav.addObject("page", page);
        //商品列表
        mav.addObject("productList", productList);
    }

    /**
     * 搜索商品,根据商品的名称
     * @param mav
     * @param productService
     * @param pname
     * @param page
     */
    public static void getProductByPname(ModelAndView mav, ProductService productService, String pname, String page){
        //当前页面号,若为空则默认为第一页
        if(page==null||page==""){
            page="1";
        }
        //商品总数
        int productCount=productService.getProductCountByPname(pname);
        //可分为多少页
        int pageCount=productCount/12;
        pageCount=productCount%12==0?pageCount:pageCount+1;
        //页数
        int num = Integer.valueOf(page);
        //类别商品
        List<Product> productList = productService.getProductByPname(pname,(num-1)*12);
        //总页面数
        mav.addObject("pageCount",pageCount);
        //类别名
        mav.addObject("pname",pname);
        //当前页面号
        mav.addObject("page", page);
        //商品列表
        mav.addObject("productList", productList);
    }
}
