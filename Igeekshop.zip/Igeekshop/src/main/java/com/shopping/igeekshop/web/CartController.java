package com.shopping.igeekshop.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.shopping.igeekshop.dto.LoginInfo;
import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Product;
import com.shopping.igeekshop.service.OrderitemService;
import com.shopping.igeekshop.service.ProductService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xlXiang
 */
@Controller
public class CartController {

    @Autowired
    private ProductService productService;
    @Autowired
    private OrderitemService orderitemService;
    /**
     * 将商品加入到购物车
     *
     * @param request
     * @param pid
     * @param quantity
     * @return
     */
    @RequestMapping(value = "/setProductToCart", method = {RequestMethod.POST,RequestMethod.GET})
    private String setProductToCart(HttpServletRequest request, String pid, Integer quantity) {
        //检测用户是否登录
        HttpSession session = request.getSession();
        LoginInfo loginInfo = (LoginInfo) session.getAttribute("userInfo");
        if (loginInfo == null) {
            //未登录，则跳转回登录页面
            return "redirect:/login";
        }

        Orderitem orderitem = new Orderitem();
        //根据传来的商品ID，获取商品信息
        Product product = productService.getProductInfoByPid(pid);
        //将商品信息写入到orderitem对象中
        orderitem.setCount(quantity);
        orderitem.setSubtotal(product.getShopPrice()*quantity);
        orderitem.setProduct(product);
        orderitem.setUid(loginInfo.getUid());
        //将商品添加到购物车
        orderitemService.addToOrderitem(loginInfo.getUid(),orderitem);
        //跳转回购物车页面
        return "redirect:/cart";
    }

    /**
     * 从购物车中删除商品，根据商品ID
     *
     * @param request
     * @param pid
     * @return
     */
    @RequestMapping(value = "/deleteProduct", method = RequestMethod.GET)
    public String deleteProduct(HttpServletRequest request, String pid) {
        //获取登录信息
        HttpSession session = request.getSession();
        LoginInfo loginInfo = (LoginInfo) session.getAttribute("userInfo");
        if (loginInfo == null) {
            //未登录，则跳转回登录页面
            return "redirect:/login";
        }
        //从购物车中删除商品
       orderitemService.delectOrderitemByPid(loginInfo.getUid(),Integer.valueOf(pid));
        //跳转回购物车页面
        return "redirect:/cart";
    }

    /**
     * 清空购物车
     * @param request
     * @return
     */
    @RequestMapping(value = "/delectOrderitemAll")
    public String delectOrderitemAll(HttpServletRequest request){
        //获取登录信息
        HttpSession session = request.getSession();
        LoginInfo loginInfo = (LoginInfo) session.getAttribute("userInfo");
        if (loginInfo == null) {
            //未登录，则跳转回登录页面
            return "redirect:/login";
        }
        //清空购物车
        orderitemService.delectOrderitemAll(loginInfo.getUid());
        return "redirect:/cart";
    }
}
