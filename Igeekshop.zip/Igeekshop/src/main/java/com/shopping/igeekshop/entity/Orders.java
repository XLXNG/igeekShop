package com.shopping.igeekshop.entity;

import lombok.Data;

import java.util.Date;

/**
 * @author xlXiang
 */
@Data
public class Orders {
    /**
     * 订单Id
     * 订单时间
     * 总金额
     * 订单状态
     * 收货地址
     * 收货人姓名
     * 电话号码
     * 用户Id
     */
    private Integer oid;
    private Date ordertime;
    private Double total;
    private Integer state;
    private String address;
    private String name;
    private String telephone;
    private Integer uid;

}
