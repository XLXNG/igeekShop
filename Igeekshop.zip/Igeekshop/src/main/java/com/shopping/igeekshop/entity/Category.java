package com.shopping.igeekshop.entity;

import lombok.Data;

/**
 * @author xlXiang
 */
@Data
public class Category {
    /**
     * 类别Id
     * 分类名称
     * 分类描述(数据库中无该字段)
     */
    private Integer cid;
    private String cname;
}
