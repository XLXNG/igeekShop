package com.shopping.igeekshop.service;

import org.apache.ibatis.annotations.Param;
import com.shopping.igeekshop.entity.Orderitem;

import java.util.List;

/**
 * @author xlXiang
 */
public interface OrderitemService {

    /**
     * 添加商品到购物车
     * @param uid
     * @param orderitem
     */
    void addToOrderitem(Integer uid,Orderitem orderitem);

    /**
     * 修改购物车中商品的数量
     * @param orderitem
     */
    void upOrderitem(@Param("orderitem")Orderitem orderitem);

    /**
     * 查询购物车中是否已经存在该商品
     * @param uid
     * @param pid
     * @return
     */
    Integer queryOrderitemIdByPid(Integer uid,Integer pid);

    /**
     * 获取购物车中所有的商品信息
     * @param uid
     * @return
     */
    List<Orderitem> getOrderitemByUid(Integer uid);

    /**
     * 删除购物车中的商品-pid
     * @param pid
     * @param uid
     */
    void delectOrderitemByPid(Integer uid,Integer pid);

    /**
     * 清空购物车
     * @param uid
     */
    void delectOrderitemAll(Integer uid);
    /**
     * 绑定订单与商品的信息
     * @param uid
     * @param oid
     */
    void setOrdersId(Integer uid,Integer oid);
}
