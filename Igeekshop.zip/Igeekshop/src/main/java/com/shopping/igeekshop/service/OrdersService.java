package com.shopping.igeekshop.service;

import com.shopping.igeekshop.entity.Orderitem;
import com.shopping.igeekshop.entity.Orders;

import java.util.List;

/**
 * @author xlXiang
 */
public interface OrdersService {

    /**
     * 提交订单
     * @param orders
     */
    void submitOrders(Orders orders);

    /**
     * 获取用户所有订单
     * @param uid
     */
    List<Orders> getAllOrders(Integer uid);

    /**
     * 查询所有订单
     */
    List<Orders> queryOrders();
    /**
     * 根据oid查询订单下商品信息
     * @param oid
     * @return
     */
    List<Orderitem> queryOrderByOid(int oid);
}
