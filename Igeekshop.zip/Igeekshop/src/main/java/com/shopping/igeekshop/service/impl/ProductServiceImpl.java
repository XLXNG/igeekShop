package com.shopping.igeekshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.shopping.igeekshop.dao.ProductDao;
import com.shopping.igeekshop.entity.Product;
import com.shopping.igeekshop.service.ProductService;

import java.util.List;
import java.util.Set;


/**
 * @author xlXiang
 */
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    ProductDao productDao;

    /**
     * 获取热门商品
     *
     * @return
     */
    @Override
    public List<Product> getHotProduct() {
        return productDao.queryHotProduct();
    }

    /**
     * 获取最新商品
     *
     * @return
     */
    @Override
    public List<Product> getLatestProduct() {
        return productDao.queryLatestProduct();
    }

    /**
     * 获取商品列表-类别
     *
     * @param categoryName
     * @param begin
     * @return
     */
    @Override
    public List<Product> getProductByCategory(String categoryName,int begin) {
        return productDao.queryProductByCategory(categoryName,begin);
    }

    /**
     * 获取商品总数-类别数量
     *
     * @param categoryName
     * @return
     */
    @Override
    public int getProductCountByCategory(String categoryName) {
        return productDao.queryProductCountByCategory(categoryName);
    }

    /**
     * 获取商品总数-商品名
     *
     * @param pname@return
     */
    @Override
    public int getProductCountByPname(String pname) {
        return productDao.queryProductCountByPname(pname);
    }

    /**
     * 获取商品总数-商品名
     *
     * @param pname
     * @return
     */
    @Override
    public List<Product> getProductByPname(String pname,int begin) {
        return productDao.queryProductByPname(pname,begin);
    }

    /**
     * 获取商品信息
     *
     * @param pid
     * @return
     */
    @Override
    public Product getProductInfoByPid(String pid) {
        return productDao.queryProductInfoByPid(pid);
    }

    /**
     * 查询浏览记录对应的商品信息
     *
     * @param pids
     * @return
     */
    @Override
    public List<Product> getProductInfoByPids(Set<String> pids) {
        return productDao.queryProductInfoByPids(pids);
    }

    /**
     * 获取所有商品信息
     *
     * @return
     */
    @Override
    public List<Product> getAllProductInfo() {
        return productDao.queryAllProductInfo();
    }

    /**
     * 删除商品
     *
     * @param pid
     */
    @Override
    public void deleteProductByPid(Integer pid) {
        productDao.deleteProductByPid(pid);
    }

    /**
     * 修改商品信息
     *
     * @param product
     */
    @Override
    public void upProductInfo(Product product) {
        productDao.upProductInfo(product);
    }

    /**
     * 添加商品
     *
     * @param product
     */
    @Override
    public void addProduct(Product product) {
        productDao.addProduct(product);
    }
}
