package com.shopping.igeekshop.dto;

import lombok.Data;

/**
 * @author xlXiang
 */
@Data
public class LoginInfo {
    private Integer uid;
    private String username;
    private String password;
}
