package com.shopping.igeekshop.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.shopping.igeekshop.entity.Category;
import com.shopping.igeekshop.service.CategoryService;

/**
 * @author
 */
@Controller
public class CategoryController {
    @Autowired
    CategoryService categoryService;

    /**
     * @author lq
     * 删除分类
     *
     * @param cid
     * @return
     */
    @RequestMapping(value = "/deleteCategoryByCid",method = RequestMethod.GET)
    public String deleteCategoryByCid(Integer cid){
        categoryService.deleteCategoryByCid(cid);
        return "redirect:admin/category/list";
    }

    /**
     *
     * 添加分类
     * @author lq
     * @param category
     * @return
     */
    @RequestMapping(value = "admin/addCategory",method = RequestMethod.POST)
    public String addCategory(Category category){
        System.out.println(category.getCname());
        categoryService.addCategory(category);
        return "redirect:/admin/category/list";
    }

    /**
     *
     * 更新分类信息
     * @author lq
     * @param category
     * @return
     */
    @RequestMapping(value = "/admin/upCategoryByCid")
    public String upCategoryByCid(Category category){
        categoryService.upCategoryByCid(category);
        return "redirect:/admin/category/list";
    }

    /**
     *
     * 查询分类根据分类ID
     * @author lq
     * @param cid
     * @return
     */
    @RequestMapping(value = "/queryCategoryByCid")
    public String queryCategoryByCid(Integer cid){
        categoryService.queryCategoryByCid(cid);
        return "redirect:admin/category/list";
    }
}
