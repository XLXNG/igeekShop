$(function () {
    //验证两次密码输入一致
    $("#password2").keyup(function () {
        var password1 = $("#password1").val();
        var password2 = $("#password2").val();
        if (password1 != password2) {
            $(".password-title").html("两次密码不一致");
            $(".password-title").show();
        }else {
            $(".password-title").hide();
        }
        if (userNameUsable() == false) {
            alert("用户名已存在")
            return false;
        }
    });
    //用户注册
    $("#register").click(function () {
        var username = $("#username").val();
        //用户名密码长度验证
        if (username.length < 6) {
            alert("用户名大于六个字符")
            return false;
        }
        //用户名可用认证

    })
    //用户名格式-事件
    $("#username").keyup(function () {
        var username = $("#username").val();
        var str = /^[A-Za-z0-9]+$/;
        //用户名位数为6-12位，且用户名由字母组成
        //测试暂时设置为3-12位
        if (username.length >= 6 && username.length < 12) {
            var username = $("#username").val();
            $.ajax({
                url: '/existEmailOrName',
                type: "get",
                data: {username},
                success: function (data) {
                    if (data.success) {
                        $(".username-title").html("用户名已存在");
                        $(".username-title").show();
                    }else {
                        $(".username-title").hide();
                    }
                }
            })

        }
        //验证用户名是否已存在-方法
        else {
            $(".username-tite").html("用户名必须大于6个字符小于12个字符");
            $(".username-tite").show();
        }


    });
});




