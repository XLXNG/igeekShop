$(function () {
    $('#username').val($.cookie('username'));
    $('#password').val($.cookie('password'));
});